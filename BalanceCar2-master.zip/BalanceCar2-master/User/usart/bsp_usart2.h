#ifndef __USART2_H
#define	__USART2_H

#include "stm32f10x.h"
#include <stdio.h>

void USART2_Config(void);
void NVIC_USART2_Configuration(void);

#endif /* __USART2_H */

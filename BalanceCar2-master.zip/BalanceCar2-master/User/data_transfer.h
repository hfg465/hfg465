#ifndef __DATA_TRANSFER_H
#define	__DATA_TRANSFER_H

#include "stm32f10x.h"

void Receive_Handle(u8 ch);

#endif /* __DATA_TRANSFER_H */

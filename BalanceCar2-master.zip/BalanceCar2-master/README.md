# BalanceCar2
基于STM32的两轮自平衡小车。

开发环境：keil 5

使用语言：c

MCU平台：STM32F103 



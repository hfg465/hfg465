/**
	****************************************************************************
	*	@file: 		ct_security_device										   											 *
	*	@author: 	版权所有 上海驰图软件科技有限公司 2014-2016
	*	@data:	 	01-March-2016											   													 *
	*	@Copyright (c) 2014--2016 Catosoft.Co.Ltd. All rights reserved.		   		 *
	*	版权所有 上海驰图软件科技有限公司 2014-2016					   							 *
	****************************************************************************
**/
#ifndef SECURIT_COMMON_H
#define  SECURIT_COMMON_H

#define IN
#define OUT
#define IN_OUT
typedef unsigned char uint8_t ;

#endif

#ifndef _BALANCE_FILTER_H
#define _BALANCE_FILTER_H

void Yijielvbo(float angle_m, float gyro_m);
void Erjielvbo(float angle_m, float gyro_m);

#endif

#ifndef _PID_H
#define _PID_H

float pid(float input, float setpoint, float kp, float ki, float kd, float dead_line);

#endif

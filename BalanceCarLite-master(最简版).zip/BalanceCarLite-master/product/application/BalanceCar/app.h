#ifndef _APP_H_
#define _APP_H_
#include "bluenrg_sdk_api.h"
#include "juma_sensor.h"


#endif //_APP_H_




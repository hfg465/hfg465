#ifndef _CONTROL_H
#define _CONTROL_H

#include "imu_sensor.h"
#include "outputdata.h"
#include "function.h"
#include "x_nucleo_iks01a1_imu_6axes.h"

void Car_Control(void);

#endif
